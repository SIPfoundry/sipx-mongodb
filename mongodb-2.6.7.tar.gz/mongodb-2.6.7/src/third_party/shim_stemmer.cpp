// This file intentionally blank.  shim_stemmer.cpp is part of the
// third_party/libstemmer_c library, which is just a placeholder for forwarding
// library dependencies.
