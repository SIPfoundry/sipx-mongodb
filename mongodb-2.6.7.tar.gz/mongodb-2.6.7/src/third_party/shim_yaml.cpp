// This file intentionally blank.  shim_yaml.cpp is part of the
// third_party/yaml library, which is just a placeholder for forwarding
// library dependencies.
