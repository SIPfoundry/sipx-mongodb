// This file intentionally blank.  shim_pcrecpp.cc is part of the
// third_party/pcrecpp library, which is just a placeholder for forwarding
// library dependencies.
